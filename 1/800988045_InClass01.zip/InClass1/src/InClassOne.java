import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.TreeMap;


/*
 * Assignment: 	In Class 1
 * Filename:	InClassOne.java
 * Author: 		Vamshedhar Reddy Chintala
 */
public class InClassOne {
	
	public static ArrayList<Movie> movies = new ArrayList<Movie>();
	public static TreeMap<Character, String> groupedMovies = new TreeMap<Character, String>();
	
	public static void parseMovie(String lineContent){
		String[] resultingTokens = lineContent.split(",");
		
		String name = resultingTokens[1];
		int year = Integer.parseInt(resultingTokens[0]);
		int collections = Integer.parseInt(resultingTokens[2]);
		
		Movie movie = new Movie(name, year, collections);
		movies.add(movie);
		
		char firstChar = movie.name.charAt(0);
		
		if(groupedMovies.containsKey(firstChar)){
			String currentList = groupedMovies.get(firstChar);
			groupedMovies.put(firstChar, currentList + ", " + movie.name);
		} else{
			groupedMovies.put(firstChar, movie.name);
		}
	}
	
	public static void readFileAtPath(String filename) {
		if (filename == null || filename.isEmpty()) {
			System.out.println("Invalid File Path");
			return;
		}
		String filePath = System.getProperty("user.dir") + "/" + filename;
		BufferedReader inputStream = null;
		
		try {
			try {
				inputStream = new BufferedReader(new FileReader(filePath));
				String lineContent = null;
				
				inputStream.readLine();
				
				while ((lineContent = inputStream.readLine()) != null) {
					parseMovie(lineContent);
				}
			}
		finally {
			if (inputStream != null)
				inputStream.close();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		
		readFileAtPath("topmovies.csv");
		
		System.out.println("Sorted Movies");
		System.out.println("");
		System.out.println("");
		
		Collections.sort(movies);
		
		for(Movie m : movies){
			System.out.println(m);
		}
		
		System.out.println("");
		System.out.println("");
		System.out.println("Grouped Movies");
		System.out.println("");
		System.out.println("");
		
		for(char key : groupedMovies.keySet()){
			System.out.println(key + ": " + groupedMovies.get(key));
		}
	}

}
