
/*
 * Assignment: 	In Class 1
 * Filename:	Movie.java
 * Author: 		Vamshedhar Reddy Chintala
 */

public class Movie implements Comparable<Movie> {
	public String name;
	public int year;
	public int collections;
	
	public Movie(String name, int year, int collections) {
		this.name = name;
		this.year = year;
		this.collections = collections;
	}

	@Override
	public String toString() {
		return name + " (" + year + ") : " + collections;
	}

	@Override
	public int compareTo(Movie o) {
		// TODO Auto-generated method stub
		return o.collections - this.collections;
	}
}
